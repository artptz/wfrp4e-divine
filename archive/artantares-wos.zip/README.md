# Change LOG

## v1.3
Added Crusader, Knight of the Fiery Heart, Rajput and Shinjin Monk careers\
Added The Nio and She'ar Khan Journals and Miracles\
Removed art for ufficial publicatione

## v1.2
Edit Sleep like the Dead, Purify the Unclean, Vestment of Purity, Ursine Strength, Winter's Sleep, Judgement to match original text\
Edit Bamboozle,  Auroch's Heart, River's Blessing, Wild Wind, Rending Paw to match update 

## v1.1
Migration to V8

## v1.0
Finalized text corrections for publishing

## v0.4
Edited Wrath of Thorns and Meat Hooks

## v0.3
Prayer Items

## v0.2
Relics and RollTables

## v0.1
Career Items and Journals
