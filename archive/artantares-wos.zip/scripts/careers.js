Hooks.on("init", () => {
    
    game.wfrp4e.utility.mergeCareerReplacements({
        human: {
            "Warrior Priest": ["Bear Tamer of Ursun", "Brother of Handrich", "Crusader", "Fire Dancer of Dazh", "Horned Hunter of Taal", "Hospitaller of Shallya", "Knight of the Fiery Heart","Night Prowler of Ranald", "Priest of Khaine", "Rajput", "Rustler of Gunndred", "Scalebearer of Verena", "Shieldmaiden of Myrmidia", "Shinkin Monk", "Sister of Sigmar", "Stormguard of Manann","Thunder Warrior", "Warrior Priest of Morr", "Warrior Priest of Sigmar", "Warrior Priest of Ulric"]
        }
    })
    
})
