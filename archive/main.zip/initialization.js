// Post to console after initialization
Hooks.once("init", () => {
    console.log("Warrior of Salvation Module Loaded");
});
